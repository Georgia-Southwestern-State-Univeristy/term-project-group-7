# **David Hugee-James**

## **Role**
	- [Project Manager / Scrum Lead]

## **Availability**
	- [Monday - Friday: 10:00am - 8:00pm CST]
	- [Preferred communication: Text (I will provide my cell phone number to the group)
    , email, chat]

## **Engineering Principle**
	- [Detailed testing and evaluation to ensure performance is testable and repeatable.]
	- [Well written documentation.]
